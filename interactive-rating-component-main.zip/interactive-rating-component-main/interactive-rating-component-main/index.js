var btnclick = document.querySelector('.component button')
var popUp = document.querySelector('.op')
var ratingbtn = document.querySelectorAll('.p')
var select = document.querySelector('span')
var component = document.querySelector('.rating2')
var component2 = document.querySelector('.component')
let isclicked = 'false'
var rates



for( const rate of ratingbtn){

    rate.addEventListener('click',(e)=>{
       isclicked = 'true'
       rates = e.target.textContent
       e.target.style.backgroundColor = 'hsl(217, 12%, 63%)'

    
    })


}

btnclick.addEventListener('click',(e)=>{
    e.preventDefault;
    if(isclicked == 'true' ){
   component.style.display  = 'flex'
    component2.style.display = 'none'
    select.textContent = rates
    }
    else if( isclicked == 'false' ){
        popUp.style.display = 'block'
    }

  })



